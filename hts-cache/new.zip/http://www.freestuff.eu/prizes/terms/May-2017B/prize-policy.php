<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250">
  <title></title>
  </head>
  <body style="font-family:arial,sans-serif; font-size:13px;">
  Prize Online: Wednesday 3rd May, 2017 at 12:00 (GMT Standard Time)<br /><br />    
  Prize Offline: Monday 4th September, 2017 at 12:00 (GMT Standard Time)<br /><br />
  The closing date for entries into this draw is Monday 4th September 2017. If the prize is no longer available at the time of awarding the prize, a substitute prize of equal value will be awarded. The winner must be aged 18 years over. The image shown is for illustrative purposes only.<br /><br /> 	
   
The first eligible entry drawn from all eligible entries received during the promotion will win their prize choice of one of the following:
<br /><br />
&pound;250 Mcdonald's Gift Card (Value: &pound;250); or<br />
&pound;100 Wagamama Gift Card (Value: &pound;100); or<br />     
&pound;100 Starbucks Gift Card (Value: &pound;100); or<br />     
&pound;100 Pizza Hut Gift Card (Value: &pound;100); or<br />       
&pound;100 Nando's Gift Card (Value: &pound;100); or<br />         
&pound;100 Swarvoski Gift Card (Value: &pound;100); or<br />    
&pound;100 MyProtein Gift Card (Value: &pound;100); or<br />    
&pound;100 Vue Gift Card (Value: &pound;100); or<br />        
GoPro Hero 4 Silver Edition Full HD Action Camera (Value: &pound;279); or<br />
Sony Playstation 4 (Value: &pound;279); or<br />            
Apple Watch Sport (Value: &pound;259); or<br />              
Microsoft Xbox One (Value: &pound;199.99); or<br />   
&pound;100 KFC Gift Card (Value: &pound;100); or<br />   
&pound;100 Pizza Express Gift Card (Value: &pound;100); or<br />   
&pound;100 Wagamama Gift Card (Value: &pound;100); or<br />           
FitBit Surge (Value: &pound;199.99); or<br />   
Nutribullet Pro 15 Piece Set (Value: &pound;129.99)
<br />
<br /><br /> </body>
</html>
